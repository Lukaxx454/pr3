
// Configuração base da API 
const API_URL = 'http://localhost:3000/api'; // ajuste para o IP/porta do 
backend 
 
// Função para pegar token 
function getToken() { 
    return localStorage.getItem('token'); 
} 
 
// Headers com autenticação 
function authHeaders() { 
    const token = getToken(); 
    return { 
        'Content-Type': 'application/json', 
        'Authorization': token ? `Bearer ${token}` : '' 
    }; 
} 
 
// ========== AUTENTICAÇÃO ========== 
async function fazerLogin() { 
    const email = document.getElementById('loginEmail').value; 
    const senha = document.getElementById('loginPassword').value; 
    try { 
        const response = await fetch(`${API_URL}/auth/login`, { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' }, 
            body: JSON.stringify({ email, senha }) 
        }); 
        const data = await response.json(); 
        if (!response.ok) throw new Error(data.error); 
        localStorage.setItem('token', data.token); 
        localStorage.setItem('user', JSON.stringify(data.user)); 
        updateMenuByUser(); 
        showView('account'); 
    } catch (error) { 
        alert('Erro no login: ' + error.message); 
    } 
} 
 
async function criarConta() { 
    const nome = document.getElementById('regNome').value; 
    const cpf = document.getElementById('regCpf').value; 
    const tel = document.getElementById('regTel').value; 
    const email = document.getElementById('regEmail').value; 
    const senha = document.getElementById('regSenha').value; 
    const conf = document.getElementById('regConfSenha').value; 
    const termos = document.getElementById('regTermos').checked; 
    if (senha !== conf) { alert('Senhas não conferem'); return; } 
    try { 
        const response = await fetch(`${API_URL}/auth/register`, { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' }, 
            body: JSON.stringify({ nome, cpf, telefone: tel, email, senha 
}) 
        }); 
        const data = await response.json(); 
        if (!response.ok) throw new Error(data.error); 
        localStorage.setItem('token', data.token); 
        localStorage.setItem('user', JSON.stringify(data.user)); 
        updateMenuByUser(); 
        showView('account'); 
    } catch (error) { 
        alert('Erro no cadastro: ' + error.message); 
    } 
} 
 
function logout() { 
    localStorage.removeItem('token'); 
    localStorage.removeItem('user'); 
    updateMenuByUser(); 
    showView('home'); 
} 
 
// ========== PRODUTOS ========== 
async function carregarProdutos() { 
    try { 
        const response = await fetch(`${API_URL}/produtos`); 
        const produtos = await response.json(); 
        localStorage.setItem('produtosCache', JSON.stringify(produtos)); 
// opcional 
        renderProductList(produtos); 
        renderHome(produtos); 
    } catch (error) { 
        console.error('Erro ao carregar produtos:', error); 
    } 
} 
 
async function salvarProduto() { 
    const produto = { 
        nome: document.getElementById('prodNome').value, 
        categoria: document.getElementById('prodCategoria').value, 
        tamanho: document.getElementById('prodTamanho').value, 
        cor: document.getElementById('prodCor').value, 
        preco: parseFloat(document.getElementById('prodPreco').value), 
        estoque: parseInt(document.getElementById('prodEstoque').value), 
        descricao: document.getElementById('prodDesc').value, 
        imagem: document.getElementById('prodImagem').value 
    }; 
    const id = document.getElementById('prodId').value; 
    const method = id ? 'PUT' : 'POST'; 
    const url = id ? `${API_URL}/produtos/${id}` : `${API_URL}/produtos`; 
    try { 
        const response = await fetch(url, { 
            method, 
            headers: authHeaders(), 
            body: JSON.stringify(produto) 
        }); 
        if (!response.ok) throw new Error('Erro ao salvar'); 
        fecharModalProduto(); 
        carregarProdutos(); // recarrega lista 
        renderAdminProducts(); // atualiza tabela admin 
    } catch (error) { 
        alert('Erro: ' + error.message); 
    } 
} 
 
async function excluirProduto(id) { 
    if (!confirm('Confirma exclusão?')) return; 
    try { 
        const response = await fetch(`${API_URL}/produtos/${id}`, { 
            method: 'DELETE', 
            headers: authHeaders() 
        }); 
        if (!response.ok) throw new Error('Erro ao excluir'); 
        carregarProdutos(); 
        renderAdminProducts(); 
    } catch (error) { 
        alert('Erro: ' + error.message); 
    } 
} 
 
// ========== FAVORITOS ========== 
async function toggleFavorito(prodId, event) { 
    event.stopPropagation(); 
    const token = getToken(); 
    if (!token) { 
        alert('Faça login para favoritar'); 
        return; 
    } 
    try { 
        const response = await 
fetch(`${API_URL}/favoritos/toggle/${prodId}`, { 
            method: 'POST', 
            headers: authHeaders() 
        }); 
        const data = await response.json(); 
        // Atualizar ícone visual 
        carregarProdutos(); // simplificado: recarrega tudo 
    } catch (error) { 
        console.error(error); 
    } 
} 
 
// ========== FINALIZAR RESERVA ========== 
async function confirmarReserva() { 
    const cart = JSON.parse(localStorage.getItem('cart')) || []; 
    if (cart.length === 0) { alert('Carrinho vazio'); return; } 
    const itens = cart.map(item => ({ 
        id_produto: item.id, 
        quantidade: item.quantity 
    })); 
    const dataRetirada = 
document.getElementById('checkoutRetirada')?.value || new 
Date().toISOString().split('T')[0]; 
    const dataDevolucao = 
document.getElementById('checkoutDevolucao')?.value || new 
Date(Date.now()+86400000*2).toISOString().split('T')[0]; 
    try { 
        const response = await fetch(`${API_URL}/alugueis`, { 
            method: 'POST', 
            headers: authHeaders(), 
            body: JSON.stringify({ itens, dataRetirada, dataDevolucao }) 
        }); 
        if (!response.ok) throw new Error('Erro ao criar reserva'); 
const data = await response.json(); 
alert(`Reserva criada! Sinal de R$ ${data.sinalPago.toFixed(2)} 
(30%)`); 
localStorage.removeItem('cart'); 
updateCartCount(); 
showView('home'); 
} catch (error) { 
alert('Erro: ' + error.message); 
}
}