
const express = require('express'); 
const router = express.Router(); 
const { getConnection, sql } = require('../db'); 
const authMiddleware = require('../middleware/authMiddleware'); 
 
// Adicionar/remover favorito (toggle) 
router.post('/toggle/:produtoId', authMiddleware, async (req, res) => { 
    const usuarioId = req.user.id; 
    const produtoId = req.params.produtoId; 
    try { 
        const pool = await getConnection(); 
        // Verificar se já existe 
        const check = await pool.request() 
            .input('usuarioId', sql.Int, usuarioId) 
            .input('produtoId', sql.Int, produtoId) 
            .query('SELECT * FROM Favoritos WHERE id_usuario = @usuarioId AND id_produto = @produtoId'); 
        if (check.recordset.length > 0) { 
            // Remover 
            await pool.request() 
                .input('usuarioId', sql.Int, usuarioId) 
                .input('produtoId', sql.Int, produtoId) 
                .query('DELETE FROM Favoritos WHERE id_usuario = @usuarioId AND id_produto = @produtoId'); 
            res.json({ favorito: false }); 
        } else { 
            // Adicionar 
            await pool.request() 
                .input('usuarioId', sql.Int, usuarioId) 
                .input('produtoId', sql.Int, produtoId) 
                .query('INSERT INTO Favoritos (id_usuario, id_produto) VALUES (@usuarioId, @produtoId)'); 
            res.json({ favorito: true }); 
        } 
    } catch (err) { 
        console.error(err); 
        res.status(500).json({ error: 'Erro ao alternar favorito' }); 
    } 
}); 
 
// Listar favoritos do usuário 
router.get('/', authMiddleware, async (req, res) => { 
    const usuarioId = req.user.id; 
    try { 
        const pool = await getConnection(); 
        const result = await pool.request() 
            .input('usuarioId', sql.Int, usuarioId) 
            .query(` 
                SELECT p.* FROM Produtos p 
                INNER JOIN Favoritos f ON p.id = f.id_produto 
                WHERE f.id_usuario = @usuarioId 
            `); 
        res.json(result.recordset); 
    } catch (err) { 
        console.error(err); 
        res.status(500).json({ error: 'Erro ao buscar favoritos' }); 
    } 
}); 
 
module.exports = router;