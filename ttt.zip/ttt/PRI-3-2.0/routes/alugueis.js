
const express = require('express'); 
const router = express.Router(); 
const { getConnection, sql } = require('../db'); 
const authMiddleware = require('../middleware/authMiddleware'); 
 
// Criar um novo aluguel (a partir do carrinho) 
router.post('/', authMiddleware, async (req, res) => { 
    const usuarioId = req.user.id; 
    const { itens, dataRetirada, dataDevolucao } = req.body; // itens: array de {id_produto, quantidade} 
    if (!itens || !dataRetirada || !dataDevolucao) { 
        return res.status(400).json({ error: 'Dados incompletos' }); 
    } 
    const pool = await getConnection(); 
    const transaction = new sql.Transaction(pool); 
    try { 
        await transaction.begin(); 
        // Calcular total e verificar estoque 
        let valorTotal = 0; 
        const itensComPreco = []; 
        for (let item of itens) { 
            const prod = await transaction.request() 
                .input('id', sql.Int, item.id_produto) 
                .query('SELECT preco, estoque FROM Produtos WHERE id = @id'); 
            if (prod.recordset.length === 0) throw new Error('Produto não encontrado'); 
            if (prod.recordset[0].estoque < item.quantidade) throw new 
Error('Estoque insuficiente para o produto ' + item.id_produto); 
            valorTotal += prod.recordset[0].preco * item.quantidade; 
            itensComPreco.push({ 
                id_produto: item.id_produto, 
                quantidade: item.quantidade, 
                valor_unitario: prod.recordset[0].preco 
            }); 
        } 
        const sinal = valorTotal * 0.3; // RN01: sinal de 30% 
        // Inserir aluguel 
        const insertAluguel = await transaction.request() 
            .input('id_cliente', sql.Int, usuarioId) 
            .input('data_retirada', sql.Date, dataRetirada) 
            .input('data_devolucao', sql.Date, dataDevolucao) 
            .input('status', sql.VarChar, 'pendente') 
            .input('valor_total', sql.Decimal, valorTotal) 
            .input('sinal_pago', sql.Decimal, sinal) 
            .query(` 
                INSERT INTO Alugueis (id_cliente, data_retirada, 
data_devolucao, status, valor_total, sinal_pago) 
                OUTPUT inserted.id 
                VALUES (@id_cliente, @data_retirada, @data_devolucao, 
@status, @valor_total, @sinal_pago) 
            `); 
        const idAluguel = insertAluguel.recordset[0].id; 
        // Inserir itens 
        for (let item of itensComPreco) { 
            await transaction.request() 
                .input('id_aluguel', sql.Int, idAluguel) 
                .input('id_produto', sql.Int, item.id_produto) 
                .input('quantidade', sql.Int, item.quantidade) 
                .input('valor_unitario', sql.Decimal, 
item.valor_unitario) 
                .query(` 
                    INSERT INTO ItensAluguel (id_aluguel, id_produto, 
quantidade, valor_unitario) 
                    VALUES (@id_aluguel, @id_produto, @quantidade, 
@valor_unitario) 
                `); 
            // Atualizar estoque (diminuir) 
            await transaction.request() 
                .input('id_produto', sql.Int, item.id_produto) 
                .input('quantidade', sql.Int, item.quantidade) 
                .query('UPDATE Produtos SET estoque = estoque - @quantidade WHERE id = @id_produto'); 
        } 
        await transaction.commit(); 
        res.status(201).json({ message: 'Aluguel criado com sucesso', id: 
idAluguel, sinalPago: sinal }); 
    } catch (err) { 
        await transaction.rollback(); 
        console.error(err); 
        res.status(500).json({ error: err.message || 'Erro ao criar aluguel' }); 
    } 
}); 
 
// Listar aluguéis do usuário 
router.get('/meus', authMiddleware, async (req, res) => { 
    const usuarioId = req.user.id; 
    try { 
        const pool = await getConnection(); 
        const result = await pool.request() 
            .input('id_cliente', sql.Int, usuarioId) 
            .query('SELECT * FROM Alugueis WHERE id_cliente = @id_cliente ORDER BY data_criacao DESC'); 
        res.json(result.recordset); 
    } catch (err) { 
        console.error(err); 
        res.status(500).json({ error: 'Erro ao buscar aluguéis' }); 
    } 
}); 
 
module.exports = router;