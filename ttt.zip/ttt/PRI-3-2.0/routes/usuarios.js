
const express = require('express'); 
const router = express.Router(); 
const { getConnection, sql } = require('../db'); 
const authMiddleware = require('../middleware/authMiddleware'); 
 
// Obter perfil do usuário logado 
router.get('/me', authMiddleware, async (req, res) => { 
    try { 
        const pool = await getConnection(); 
        const result = await pool.request() 
            .input('id', sql.Int, req.user.id) 
            .query('SELECT id, nome, cpf, telefone, email, tipo, data_cadastro FROM Usuarios WHERE id = @id'); 
        if (result.recordset.length === 0) { 
            return res.status(404).json({ error: 'Usuário não encontrado' 
}); 
        } 
        res.json(result.recordset[0]); 
    } catch (err) { 
        console.error(err); 
        res.status(500).json({ error: 'Erro ao buscar perfil' }); 
    } 
}); 
// Atualizar perfil 
router.put('/me', authMiddleware, async (req, res) => { 
const { nome, telefone } = req.body; 
try { 
const pool = await getConnection(); 
await pool.request() 
.input('id', sql.Int, req.user.id) 
.input('nome', sql.VarChar, nome) 
.input('telefone', sql.VarChar, telefone) 
.query('UPDATE Usuarios SET nome = @nome, telefone = @telefone WHERE id = @id'); 
res.json({ message: 'Perfil atualizado' }); 
} catch (err) { 
console.error(err); 
res.status(500).json({ error: 'Erro ao atualizar perfil' }); 
}
}); 
module.exports = router; 