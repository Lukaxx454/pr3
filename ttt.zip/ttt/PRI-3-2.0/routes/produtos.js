
const express = require('express'); 
const router = express.Router(); 
const { getConnection, sql } = require('../db'); 
const authMiddleware = require('../middleware/authMiddleware'); 
 
// Listar todos os produtos (público) 
router.get('/', async (req, res) => { 
    try { 
        const pool = await getConnection(); 
        const result = await pool.request().query('SELECT * FROM Produtos'); 
        res.json(result.recordset); 
    } catch (err) { 
        console.error(err); 
        res.status(500).json({ error: 'Erro ao buscar produtos' }); 
    } 
}); 
 
// Buscar produto por ID (público) 
router.get('/:id', async (req, res) => { 
    const { id } = req.params; 
    try { 
        const pool = await getConnection(); 
        const result = await pool.request() 
            .input('id', sql.Int, id) 
            .query('SELECT * FROM Produtos WHERE id = @id'); 
        if (result.recordset.length === 0) { 
            return res.status(404).json({ error: 'Produto não encontrado' 
}); 
        } 
        res.json(result.recordset[0]); 
    } catch (err) { 
        console.error(err); 
        res.status(500).json({ error: 'Erro ao buscar produto' }); 
    } 
}); 
 
// Criar produto (somente admin) 
router.post('/', authMiddleware, async (req, res) => { 
    if (req.user.tipo !== 'admin') { 
        return res.status(403).json({ error: 'Acesso negado' }); 
    } 
    const { nome, categoria, tamanho, cor, preco, estoque, descricao, 
imagem } = req.body; 
    if (!nome || !preco || !estoque) { 
        return res.status(400).json({ error: 'Nome, preço e estoque são obrigatórios' }); 
    } 
    try { 
        const pool = await getConnection(); 
        const result = await pool.request() 
            .input('nome', sql.VarChar, nome) 
            .input('categoria', sql.VarChar, categoria || null) 
            .input('tamanho', sql.VarChar, tamanho || null) 
            .input('cor', sql.VarChar, cor || null) 
            .input('preco', sql.Decimal, preco) 
            .input('estoque', sql.Int, estoque) 
            .input('descricao', sql.Text, descricao || null) 
            .input('imagem', sql.VarChar, imagem || null) 
            .query(` 
                INSERT INTO Produtos (nome, categoria, tamanho, cor, 
preco, estoque, descricao, imagem) 
                OUTPUT inserted.id 
                VALUES (@nome, @categoria, @tamanho, @cor, @preco, 
@estoque, @descricao, @imagem) 
            `); 
        res.status(201).json({ message: 'Produto criado', id: 
result.recordset[0].id }); 
    } catch (err) { 
        console.error(err); 
        res.status(500).json({ error: 'Erro ao criar produto' }); 
    } 
}); 
 
// Atualizar produto (admin) 
router.put('/:id', authMiddleware, async (req, res) => { 
    if (req.user.tipo !== 'admin') { 
        return res.status(403).json({ error: 'Acesso negado' }); 
    } 
    const { id } = req.params; 
    const { nome, categoria, tamanho, cor, preco, estoque, descricao, 
imagem } = req.body; 
    try { 
        const pool = await getConnection(); 
        await pool.request() 
            .input('id', sql.Int, id) 
            .input('nome', sql.VarChar, nome) 
            .input('categoria', sql.VarChar, categoria) 
            .input('tamanho', sql.VarChar, tamanho) 
            .input('cor', sql.VarChar, cor) 
            .input('preco', sql.Decimal, preco) 
            .input('estoque', sql.Int, estoque) 
            .input('descricao', sql.Text, descricao) 
            .input('imagem', sql.VarChar, imagem) 
            .query(` 
                UPDATE Produtos SET 
                    nome = @nome, 
                    categoria = @categoria, 
                    tamanho = @tamanho, 
                    cor = @cor, 
                    preco = @preco, 
                    estoque = @estoque, 
                    descricao = @descricao, 
                    imagem = @imagem 
                WHERE id = @id 
            `); 
        res.json({ message: 'Produto atualizado' }); 
    } catch (err) { 
        console.error(err); 
        res.status(500).json({ error: 'Erro ao atualizar produto' }); 
    } 
}); 
 
// Deletar produto (admin) 
router.delete('/:id', authMiddleware, async (req, res) => { 
    if (req.user.tipo !== 'admin') { 
        return res.status(403).json({ error: 'Acesso negado' }); 
    } 
    const { id } = req.params; 
    try { 
        const pool = await getConnection(); 
        await pool.request() 
            .input('id', sql.Int, id) 
            .query('DELETE FROM Produtos WHERE id = @id'); 
        res.json({ message: 'Produto deletado' }); 
    } catch (err) { 
        console.error(err); 
        res.status(500).json({ error: 'Erro ao deletar produto' }); 
    } 
}); 
 
module.exports = router; 