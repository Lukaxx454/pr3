
const express = require('express'); 
const router = express.Router(); 
const bcrypt = require('bcrypt'); 
const jwt = require('jsonwebtoken'); 
const { getConnection, sql } = require('../db'); 
 
// Registro de novo usuário 
router.post('/register', async (req, res) => { 
    const { nome, cpf, telefone, email, senha } = req.body; 
    if (!nome || !cpf || !email || !senha) { 
        return res.status(400).json({ error: 'Campos obrigatórios faltando' }); 
    } 
    try { 
        const pool = await getConnection(); 
        // Verificar se usuário já existe 
        const existing = await pool.request() 
            .input('email', sql.VarChar, email) 
            .input('cpf', sql.VarChar, cpf) 
            .query('SELECT id FROM Usuarios WHERE email = @email OR cpf = @cpf'); 
        if (existing.recordset.length > 0) { 
            return res.status(409).json({ error: 'E-mail ou CPF já cadastrado' }); 
        } 
        // Hash da senha 
        const hashedPassword = await bcrypt.hash(senha, 10); 
        const result = await pool.request() 
            .input('nome', sql.VarChar, nome) 
            .input('cpf', sql.VarChar, cpf) 
            .input('telefone', sql.VarChar, telefone || null) 
            .input('email', sql.VarChar, email) 
            .input('senha', sql.VarChar, hashedPassword) 
            .input('tipo', sql.VarChar, 'cliente') 
            .query(` 
                INSERT INTO Usuarios (nome, cpf, telefone, email, senha, 
tipo) 
                OUTPUT inserted.id 
                VALUES (@nome, @cpf, @telefone, @email, @senha, @tipo) 
            `); 
        const userId = result.recordset[0].id; 
        const token = jwt.sign({ id: userId, email, tipo: 'cliente' }, 
process.env.JWT_SECRET, { expiresIn: '7d' }); 
        res.status(201).json({ message: 'Usuário criado', token, user: { 
id: userId, nome, email, tipo: 'cliente' } }); 
    } catch (err) { 
        console.error(err); 
        res.status(500).json({ error: 'Erro no servidor' }); 
    } 
}); 
 
// Login 
router.post('/login', async (req, res) => { 
    const { email, senha } = req.body; 
    if (!email || !senha) { 
        return res.status(400).json({ error: 'E-mail e senha obrigatórios' }); 
    } 
    try { 
        const pool = await getConnection(); 
        const result = await pool.request() 
            .input('email', sql.VarChar, email) 
            .query('SELECT id, nome, email, senha, tipo FROM Usuarios WHERE email = @email'); 
        if (result.recordset.length === 0) { 
            return res.status(401).json({ error: 'Credenciais inválidas' 
}); 
        } 
        const user = result.recordset[0]; 
        const match = await bcrypt.compare(senha, user.senha); 
        if (!match) { 
            return res.status(401).json({ error: 'Credenciais inválidas' 
}); 
        } 
        const token = jwt.sign({ id: user.id, email: user.email, tipo: 
user.tipo }, process.env.JWT_SECRET, { expiresIn: '7d' }); 
        res.json({ message: 'Login bem-sucedido', token, user: { id: 
user.id, nome: user.nome, email: user.email, tipo: user.tipo } }); 
    } catch (err) { 
        console.error(err); 
        res.status(500).json({ error: 'Erro no servidor' }); 
    } 
}); 
 
module.exports = router;